"""Test suite for claif_cod."""


def test_version():
    """Verify package exposes version."""
    import claif_cod

    assert claif_cod.__version__
